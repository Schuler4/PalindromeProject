//***********************************************************************
//   Taylor Schuler
//
//   Chapter 8  Excercise #5
//
//   Used for implementation of info.h
//
//***********************************************************************

#include "info.h"

//-----------------------------------
// Default Constructor
//-----------------------------------
info::info(string assignName)
{
	instructor = "Ms. Ligocki";
	firstName = "Taylor";
	lastName = "Schuler";
	course = "Intro to Data Structures";
	assignmentName = assignName;
}


//-----------------------------------
//  Used to display output for
//  info class
//-----------------------------------
void info::displayInfo(string currentDate)
{
	cout << "*******************************************" << endl;
	cout << "Name          : " << firstName << " " << lastName << endl;
	cout << "Course        : " << course << endl;
	cout << "Instructor    : " << instructor << endl;
	cout << "Assignment    : " << assignmentName << endl;
	cout << "Compile Date  : " << __DATE__ << endl;
	cout << "Current Date  : " << currentDate << endl;
	cout << "*******************************************" << endl;
}


