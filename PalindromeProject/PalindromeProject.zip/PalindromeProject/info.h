
//***********************************************************************
//   Taylor Schuler
//
//   Chapter 8  Excercise #5
//
//   Used to list variables and method prototypes for info Class
//
//***********************************************************************

#ifndef INFO_H
#define INFO_H // Include guards. Indicates that class will not be used more than once
#include <string>
#include <iostream>
using namespace std;

class info
{

private:
	string instructor; //Holds name of instructor
	string firstName; //Holds first name
	string lastName; //Holds last name
	string course; //Holds course name
	string assignmentName; //holds assignment name


public:
	info(string assignName);  //Default Constructor
	void displayInfo(string currentDate);  //Used to display output for info class

};

#endif